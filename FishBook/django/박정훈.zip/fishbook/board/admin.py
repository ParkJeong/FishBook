from django.contrib import admin
from board.models import Board
# Register your models here.

admin.site.register(Board)
